#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
总体刚度矩阵组装与桁架结构求解程序
本程序实现了杆单元和二维桁架单元的：
  1. 前处理（读取 JSON 模型数据、生成对号矩阵 LM）
  2. 单元分析（计算单元刚度矩阵）
  3. 组装（根据 LM 直接组装到总体刚度矩阵 K）
  4. 方程求解（缩流法处理位移边界条件，求解位移和反力）
  5. 后处理（计算单元应力和轴力）
作者:龙波 202311012147
"""
import sys
import json
import numpy as np

# ==============================================================================
# 模块一：数据模型 (model.py)
# 说明：定义有限元模型的所有数据，作为全局数据容器供各模块共享访问
# ==============================================================================

# --- 基本结构参数 ---
Title = ""          # 模型标题
nsd   = 0           # 空间维数（1=一维, 2=二维, 3=三维）
ndof  = 0           # 每个节点的自由度数
nnp   = 0           # 节点总数 (number of nodal points)
nel   = 0           # 单元总数 (number of elements)
nen   = 0           # 每单元节点数 (number of element nodes)，杆单元固定为2
neq   = 0           # 总自由度数 = nnp * ndof
nd    = 0           # 已知（约束/固定）位移的自由度数

# --- 单元属性数组 ---
CArea = np.array([])  # 各单元截面积
E_mod = np.array([])  # 各单元弹性模量
leng  = np.array([])  # 各单元长度（计算得出）

# --- 节点坐标 ---
x = np.array([])      # 节点 x 坐标
y = np.array([])      # 节点 y 坐标（一维时全为零）

# --- 单元连接与自由度映射 ---
IEN = np.array([[]])  # 单元节点号数组，形状 [nel, nen]，值为全局节点号（1-based）
LM  = np.array([[]])  # 对号矩阵（Location Matrix），形状 [nen*ndof, nel]，值为全局自由度号（0-based）

# --- 总体刚度矩阵、载荷和位移 ---
K = np.array([[]])    # 总体刚度矩阵，形状 [neq, neq]
f = np.array([[]])    # 节点力列阵（已知外力），形状 [neq, 1]
d = np.array([[]])    # 总体位移列阵，形状 [neq, 1]

# --- 边界条件 ---
fixed_dof    = np.array([])   # 被固定的自由度编号（1-based，来自输入文件）
fixed_value  = np.array([])   # 对应的固定位移值
force_dof    = np.array([])   # 受外力作用的自由度编号（1-based）
force_value  = np.array([])   # 对应的外力值

# --- 后处理结果 ---
stress = np.array([])  # 各单元应力


# ==============================================================================
# 模块二：前处理 (preprocess.py)
# 说明：读取 JSON 格式的模型数据文件，初始化所有模型参数
#       生成对号矩阵 LM（Location Matrix），建立单元局部自由度与总体自由度的映射
# ==============================================================================

def read_input(json_file):
    """
    从 JSON 文件读取有限元模型数据并初始化所有全局变量。

    JSON 文件采用 1-based 自由度编号（与课程要求一致），
    程序内部统一转换为 0-based 编号。

    参数：
        json_file: str - JSON 输入文件路径
    """
    global Title, nsd, ndof, nnp, nel, nen, neq, nd
    global CArea, E_mod, x, y, IEN, LM, K, f, d
    global fixed_dof, fixed_value, force_dof, force_value, leng, stress

    # --- 读取并解析 JSON 文件 ---
    with open(json_file, 'r', encoding='utf-8') as fp:
        data = json.load(fp)

    # --- 基本参数 ---
    Title = data.get('Title', 'Untitled')
    nsd   = int(data['nsd'])          # 空间维数
    ndof  = int(data['ndof'])         # 每节点自由度数
    nnp   = int(data['nnp'])          # 节点数
    nel   = int(data['nel'])          # 单元数
    nen   = int(data['nen'])          # 每单元节点数（杆单元为 2）
    neq   = nnp * ndof                # 系统总自由度数
    nd    = int(data.get('nd', len(data.get('fixed_dof', []))))  # 约束自由度数

    # --- 单元属性：截面积和弹性模量 ---
    CArea = np.array(data['CArea'], dtype=float)
    E_mod = np.array(data['E'], dtype=float)

    # --- 节点坐标 ---
    x = np.array(data['x'], dtype=float)
    y = np.array(data['y'], dtype=float)

    # --- 单元连接数组 IEN（输入文件为 1-based） ---
    IEN = np.array(data['IEN'], dtype=int)  # 形状 [nel, nen]，值为 1-based 全局节点号

    # --- 边界条件：输入文件为 1-based 自由度编号，转换为 0-based ---
    fixed_dof   = np.array(data.get('fixed_dof', []), dtype=int) - 1    # 转 0-based
    fixed_value = np.array(data.get('fixed_value', []), dtype=float)
    force_dof   = np.array(data.get('force_dof', []), dtype=int) - 1    # 转 0-based
    force_value = np.array(data.get('force_value', []), dtype=float)

    # --- 初始化总体数组 ---
    K      = np.zeros((neq, neq))     # 总体刚度矩阵
    f      = np.zeros((neq, 1))       # 总体节点力列阵
    d      = np.zeros((neq, 1))       # 总体位移列阵
    leng   = np.zeros(nel)            # 各单元长度
    stress = np.zeros(nel)            # 各单元应力

    # --- 施加已知节点力 ---
    for i, dof in enumerate(force_dof):
        f[dof, 0] = force_value[i]

    # --- 施加已知位移（用于后续缩流法求解） ---
    for i, dof in enumerate(fixed_dof):
        d[dof, 0] = fixed_value[i]

    # --- 生成对号矩阵 LM ---
    build_LM()

    # --- 输出模型信息 ---
    print(f"{'='*60}")
    print(f"  模型标题: {Title}")
    print(f"  空间维数(nsd)={nsd}, 节点数(nnp)={nnp}, 单元数(nel)={nel}")
    print(f"  每节点自由度(ndof)={ndof}, 总自由度(neq)={neq}")
    print(f"  约束自由度数(nd)={nd}")
    print(f"{'='*60}")


def build_LM():
    """
    生成对号矩阵（Location Matrix）LM。

    LM 矩阵记录了每个单元的各个局部自由度对应的总体自由度编号。
    形状为 [nen*ndof, nel]，其中：
      - 行索引 i = j*ndof + m，表示单元内第 j 个节点的第 m 个自由度
      - 列索引 e 表示单元编号
      - LM[i, e] 的值为该自由度对应的总体自由度编号（0-based）

    生成公式（来自课件）：
      LM[i, e] = ndof * (IEN[e, j] - 1) + m
    其中 IEN[e, j] 为 1-based 全局节点号。
    """
    global LM
    LM = np.zeros((nen * ndof, nel), dtype=int)

    for e in range(nel):                    # 遍历每个单元
        for j in range(nen):                # 遍历单元内每个节点（局部编号 0, 1）
            for m in range(ndof):           # 遍历每个节点的自由度（局部编号 0, 1, ...）
                i = j * ndof + m            # 单元内自由度的行索引
                # IEN[e, j] 为 1-based 全局节点号，转换为 0-based 总体自由度号
                LM[i, e] = ndof * (IEN[e, j] - 1) + m

    # --- 输出 LM 矩阵 ---
    print("\n对号矩阵 LM:")
    print(LM)


# ==============================================================================
# 模块三：单元分析 (element.py)
# 说明：计算各类型杆单元的单元刚度矩阵
# ==============================================================================

def truss_element(e):
    """
    计算第 e 个杆/桁架单元的单元刚度矩阵 ke。

    一维杆单元 (ndof=1):
        ke = (EA/L) * [[1, -1], [-1, 1]]

    二维桁架单元 (ndof=2):
        ke = (EA/L) * [[ c²,  cs, -c², -cs],
                        [ cs,  s², -cs, -s²],
                        [-c², -cs,  c²,  cs],
                        [-cs, -s²,  cs,  s²]]
    其中 c = cos(φ) 为 x 方向余弦，s = sin(φ) 为 y 方向余弦，
    φ 为单元轴线与全局 x 轴的夹角。

    参数：
        e: int - 单元编号（0-based）

    返回：
        ke: numpy.ndarray - 单元刚度矩阵，形状 [nen*ndof, nen*ndof]
    """
    # --- 获取单元节点的全局坐标 ---
    # IEN[e] 为 1-based 节点号，减 1 转为 0-based 索引
    node_ids = IEN[e] - 1          # 该单元两个节点的 0-based 编号
    x1, y1 = x[node_ids[0]], y[node_ids[0]]   # 节点1坐标
    x2, y2 = x[node_ids[1]], y[node_ids[1]]   # 节点2坐标

    # --- 计算单元长度 ---
    dx = x2 - x1
    dy = y2 - y1
    length = np.sqrt(dx**2 + dy**2)
    leng[e] = length                # 存储单元长度供后处理使用

    # --- 计算刚度系数 (EA/L) ---
    const = CArea[e] * E_mod[e] / length

    if ndof == 1:
        # 一维杆单元刚度矩阵
        ke = const * np.array([[ 1, -1],
                               [-1,  1]])
    elif ndof == 2:
        # 方向余弦
        c = dx / length             # cos(φ)
        s = dy / length             # sin(φ)

        # 二维桁架单元刚度矩阵（课件公式）
        ke = const * np.array([
            [ c*c,  c*s, -c*c, -c*s],
            [ c*s,  s*s, -c*s, -s*s],
            [-c*c, -c*s,  c*c,  c*s],
            [-c*s, -s*s,  c*s,  s*s]
        ])
    else:
        raise ValueError(f"不支持的自由度维度 ndof={ndof}，请扩展程序。")

    return ke


# ==============================================================================
# 模块四：组装 (assembly.py)
# 说明：根据对号矩阵 LM，将单元刚度矩阵直接组装到总体刚度矩阵 K
# ==============================================================================

def assemble(e, ke):
    """
    将第 e 个单元的刚度矩阵 ke 直接组装到总体刚度矩阵 K。
    """
    ndof_elem = nen * ndof   # 每个单元的总自由度数
    for a in range(ndof_elem):
        i = LM[a, e]         # 第 a 个单元自由度对应的总体自由度号
        for b in range(ndof_elem):
            j = LM[b, e]     # 第 b 个单元自由度对应的总体自由度号
            K[i, j] += ke[a, b]


# ==============================================================================
# 模块五：方程求解 (solver.py)
# 说明：使用缩流法（缩减法/分块法）处理位移边界条件，求解总体刚度方程
# ==============================================================================

def solve_system():
    """
    采用缩流法（Partition and Solve / Reduction Method）：
    """
    # --- 边界条件处理前：检查总体刚度矩阵是否奇异 ---
    # 奇异矩阵的行列式为零（未施加边界条件时，结构存在刚体位移）
    try:
        det_K = np.linalg.det(K)
        if abs(det_K) < 1e-10:
            print(f"\n施加边界条件前 K 的行列式 ≈ 0，矩阵奇异 ✓")
        else:
            print(f"\n施加边界条件前 K 的行列式 = {det_K:.6e}（非奇异）")
    except np.linalg.LinAlgError:
        print("\n施加边界条件前 K 奇异 ✓")

    # --- 对自由度进行排序：先约束自由度 (E)，后自由自由度 (F) ---
    # fixed_dof 已是 0-based
    all_dofs     = np.arange(neq)
    fixed_set    = set(fixed_dof.tolist())
    free_dofs    = np.array([i for i in all_dofs if i not in fixed_set], dtype=int)
    constrained_dofs = np.array(sorted(fixed_set), dtype=int)

    nd = len(constrained_dofs)      # 约束自由度数
    nf = len(free_dofs)             # 自由自由度数

    # --- 提取分块矩阵（缩流法的核心步骤） ---
    # 分块形式：[K_E  K_EF ] [d_E]   [r_E]
    #           [K_EF^T K_F] [d_F] = [f_F]
    K_E  = K[np.ix_(constrained_dofs, constrained_dofs)]     # 约束自由度对应的子矩阵
    K_F  = K[np.ix_(free_dofs, free_dofs)]                   # 自由自由度对应的子矩阵
    K_EF = K[np.ix_(constrained_dofs, free_dofs)]            # 交叉子矩阵

    # 已知位移和已知外力
    d_E = d[constrained_dofs, :].copy()       # 已知位移（边界条件）
    f_F = f[free_dofs, :].copy()              # 自由自由度上的外力

    # --- 求解缩减方程 ---
    # K_F * d_F = f_F - K_EF^T * d_E
    rhs = f_F - K_EF.T @ d_E
    d_F = np.linalg.solve(K_F, rhs)

    # --- 检查缩减矩阵是否非奇异 ---
    try:
        det_KF = np.linalg.det(K_F)
        if abs(det_KF) > 1e-10:
            print(f"施加边界条件后缩减矩阵 K_F 的行列式 = {det_KF:.6e}，非奇异 ✓")
        else:
            print(f"施加边界条件后缩减矩阵 K_F 仍奇异，请检查边界条件！")
    except np.linalg.LinAlgError:
        print("缩减矩阵求解失败，请检查边界条件。")

    # --- 重构完整位移列阵 ---
    d[constrained_dofs, :] = d_E
    d[free_dofs, :]        = d_F

    # --- 计算约束反力 ---
    # r_E = K_E * d_E + K_EF * d_F
    reactions = K_E @ d_E + K_EF @ d_F

    # --- 输出结果 ---
    print("\n" + "="*60)
    print("  求解结果")
    print("="*60)
    print("\n节点位移 d:")
    for i in range(neq):
        print(f"  d[{i+1}] = {d[i, 0]:.6f}")

    print("\n约束反力:")
    for i, dof in enumerate(constrained_dofs):
        print(f"  r[自由度{dof+1}] = {reactions[i, 0]:.6f}")

    # --- 平衡校核：约束反力之和 + 外力之和 = 0 ---
    total_reaction = np.sum(reactions)
    total_force    = np.sum(f[free_dofs, :])
    print(f"\n平衡校核: Σr + Σf = {total_reaction:.6f} + {total_force:.6f} = "
          f"{total_reaction + total_force:.6e}")

    return reactions


# ==============================================================================
# 模块六：后处理 (postprocess.py)
# 说明：根据求得的总体位移，提取单元位移并计算单元应力和轴力
# ==============================================================================

def compute_element_stress():
    """
    计算并输出各单元的应力和轴力。

    一维杆单元：
        σ = (E/L) * [-1, 1] · d_e

    二维桁架单元：
        σ = (E/L) * [-c, -s, c, s] · d_e
    其中 c, s 为方向余弦，d_e 为单元节点位移列阵。

    单元轴力：
        N = σ * A
    """
    print("\n" + "="*60)
    print("  后处理：单元应力与轴力")
    print("="*60)
    header = f"{'单元':>4s}  {'长度':>10s}  {'方向余弦(c,s)':>20s}  {'应力':>14s}  {'轴力':>14s}"
    print(header)
    print("-"*70)

    for e in range(nel):
        # --- 提取单元节点位移 ---
        # 从总体位移 d 中，根据 LM 映射提取该单元的节点位移
        de = d[LM[:, e], 0]     # 形状 [nen*ndof]

        length = leng[e]
        E_e = E_mod[e]
        A_e = CArea[e]

        if ndof == 1:
            # 一维杆单元应力
            stress[e] = (E_e / length) * (np.array([-1, 1]) @ de)
            print(f"  {e+1:3d}  {length:10.4f}  {'N/A':>20s}  {stress[e]:14.6f}  "
                  f"{stress[e]*A_e:14.6f}")

        elif ndof == 2:
            # --- 计算方向余弦 ---
            node_ids = IEN[e] - 1
            dx = x[node_ids[1]] - x[node_ids[0]]
            dy = y[node_ids[1]] - y[node_ids[0]]
            c = dx / length     # cos(φ)
            s = dy / length     # sin(φ)

            # 二维桁架单元应力
            stress[e] = (E_e / length) * (np.array([-c, -s, c, s]) @ de)
            N_e = stress[e] * A_e     # 轴力
            print(f"  {e+1:3d}  {length:10.4f}  ({c:8.4f}, {s:8.4f})  "
                  f"{stress[e]:14.6f}  {N_e:14.6f}")


# ==============================================================================
# 主程序：串联五个模块，完成有限元分析的完整流程
# ==============================================================================

def run_analysis(json_file):
    """
    有限元分析主程序，按顺序执行五个步骤：
    (1) 前处理：读取模型数据、生成 LM
    (2) 单元分析：计算各单元刚度矩阵
    (3) 组装：直接组装到总体刚度矩阵
    (4) 方程求解：缩流法施加边界条件并求解
    (5) 后处理：计算单元应力和轴力

    参数：
        json_file: str - JSON 格式的模型数据文件路径
    """
    # ------------------------------------------------------------------
    # 步骤 (1)：前处理 — 读取模型数据、生成对号矩阵 LM
    # ------------------------------------------------------------------
    print("\n" + "#"*60)
    print("#  步骤 1：前处理")
    print("#"*60)
    read_input(json_file)

    # ------------------------------------------------------------------
    # 步骤 (2)：单元分析 — 计算每个单元的刚度矩阵
    # ------------------------------------------------------------------
    print("\n" + "#"*60)
    print("#  步骤 2：单元分析")
    print("#"*60)
    for e in range(nel):
        ke = truss_element(e)
        print(f"\n单元 {e+1} 的刚度矩阵 ke:")
        print(np.array2string(ke, precision=6, suppress_small=True))

    # ------------------------------------------------------------------
    # 步骤 (3)：组装 — 根据 LM 将单元刚度矩阵直接组装到总体刚度矩阵
    # ------------------------------------------------------------------
    print("\n" + "#"*60)
    print("#  步骤 3：组装总体刚度矩阵")
    print("#"*60)

    # 注意：需要重新计算单元刚度矩阵以填充 leng 数组
    # （步骤2中已计算但未保存 ke，这里重新计算并组装）
    K[:, :] = 0.0   # 重置总体刚度矩阵
    for e in range(nel):
        ke = truss_element(e)
        assemble(e, ke)

    # --- 输出总体刚度矩阵 ---
    print("\n总体刚度矩阵 K:")
    print(np.array2string(K, precision=6, suppress_small=True))

    # --- 检查对称性 ---
    if np.allclose(K, K.T):
        print("\n总体刚度矩阵 K 是对称的 ✓")
    else:
        max_diff = np.max(np.abs(K - K.T))
        print(f"\n总体刚度矩阵 K 不对称！最大差异 = {max_diff:.6e}")

    # --- 检查对角元非负性 ---
    diag = np.diag(K)
    if np.all(diag >= -1e-10):
        print("总体刚度矩阵 K 的对角元素均为非负 ✓")
    else:
        print("警告：总体刚度矩阵 K 存在负对角元素！")

    # --- 检查稀疏性 ---
    total_elements  = K.size
    zero_elements   = np.sum(np.abs(K) < 1e-12)
    sparsity        = zero_elements / total_elements * 100
    print(f"总体刚度矩阵稀疏性: {zero_elements}/{total_elements} = {sparsity:.1f}% 零元素")

    # ------------------------------------------------------------------
    # 步骤 (4)：方程求解 — 施加边界条件，求解位移和约束反力
    # ------------------------------------------------------------------
    print("\n" + "#"*60)
    print("#  步骤 4：方程求解")
    print("#"*60)
    reactions = solve_system()

    # ------------------------------------------------------------------
    # 步骤 (5)：后处理 — 计算单元应力和轴力
    # ------------------------------------------------------------------
    print("\n" + "#"*60)
    print("#  步骤 5：后处理")
    print("#"*60)
    compute_element_stress()

    return K, d, reactions, stress


# ==============================================================================
# 验证算例的输入文件生成与结果校核
# ==============================================================================

def create_example1_json():
    """
    创建算例1（一维两单元杆结构）的 JSON 输入文件。

    结构描述：
      节点:  1 ----[单元1]---- 2 ----[单元2]---- 3
      坐标:  x=0            x=1              x=2
      属性:  E1A1/L1=100     E2A2/L2=200
      边界:  d1=0（节点1固定）
      载荷:  f2=0, f3=10
    """
    data = {
        "Title": "1D Two-Element Bar (Example 1)",
        "nsd": 1,
        "ndof": 1,
        "nnp": 3,
        "nel": 2,
        "nen": 2,
        "E": [1.0, 1.0],            # 弹性模量（任意值）
        "CArea": [100.0, 200.0],     # 截面积，使得 EA/L = 100, 200
        "x": [0.0, 1.0, 2.0],
        "y": [0.0, 0.0, 0.0],
        "IEN": [[1, 2], [2, 3]],
        "nd": 1,
        "fixed_dof": [1],
        "fixed_value": [0.0],
        "force_dof": [2, 3],
        "force_value": [0.0, 10.0]
    }
    fname = "truss_1d.json"
    with open(fname, 'w', encoding='utf-8') as fp:
        json.dump(data, fp, indent=2)
    print(f"已生成算例1输入文件: {fname}")
    return fname


def create_example2_json():
    """
    创建算例2（二维两杆桁架结构）的 JSON 输入文件。

    结构描述（来自课程例题 2.2 / 作业算例 2）：
      节点1: (1, 0) — 固定 (u1=0, v1=0)
      节点2: (0, 0) — 固定 (u2=0, v2=0)
      节点3: (1, 1) — 受力 Fx=10, Fy=0
      单元1: 1-3（竖杆，EA/L = AE/L）
      单元2: 2-3（斜杆，EA/L = AE/(√2 L)）
    """
    data = {
        "Title": "2D Two-Bar Truss (Example 2)",
        "nsd": 2,
        "ndof": 2,
        "nnp": 3,
        "nel": 2,
        "nen": 2,
        "E": [1.0, 1.0],
        "CArea": [1.0, 1.0],
        "x": [1.0, 0.0, 1.0],
        "y": [0.0, 0.0, 1.0],
        "IEN": [[1, 3], [2, 3]],
        "nd": 4,
        "fixed_dof": [1, 2, 3, 4],
        "fixed_value": [0.0, 0.0, 0.0, 0.0],
        "force_dof": [5, 6],
        "force_value": [10.0, 0.0]
    }
    fname = "truss_2d.json"
    with open(fname, 'w', encoding='utf-8') as fp:
        json.dump(data, fp, indent=2)
    print(f"已生成算例2输入文件: {fname}")
    return fname


def verify_example1():
    """
    算例1结果校核。
    检查项：
      1. 总体刚度矩阵 K
      2. 节点位移 d
      3. 节点1约束反力
      4. 边界条件前后的奇异性
    """
    print("\n" + "="*60)
    print("  算例1 结果校核")
    print("="*60)

    # 预期总体刚度矩阵
    K_expected = np.array([[ 100, -100,    0],
                           [-100,  300, -200],
                           [   0, -200,  200]], dtype=float)
    # 预期位移
    d_expected = np.array([[0.0], [0.1], [0.15]])

    print("\n检查1: 总体刚度矩阵")
    if np.allclose(K, K_expected, atol=1e-8):
        print("  总体刚度矩阵 K 与预期一致 ✓")
    else:
        print("  总体刚度矩阵 K 与预期不一致 ✗")
        print(f"  预期:\n{K_expected}")
        print(f"  实际:\n{K}")

    print("\n检查2: 节点位移")
    if np.allclose(d, d_expected, atol=1e-8):
        print("  节点位移与预期一致 ✓")
        print(f"  d = {d.flatten()}")
    else:
        print("  节点位移与预期不一致 ✗")

    print("\n检查3: 节点1约束反力")
    r1 = -10.0  # 预期约束反力
    # 从总体刚度方程计算：r1 = K[0,:] @ d
    r1_calc = (K[0:1, :] @ d)[0, 0]
    print(f"  计算得 r1 = {r1_calc:.6f}，预期 r1 = {r1}")
    if abs(r1_calc - r1) < 1e-6:
        print("  约束反力正确，方向与外载平衡 ✓")

    print("\n检查4: 边界条件前后的奇异性")
    # 前面 solve_system() 已打印奇异性检查结果
    print("  （见求解过程中的行列式检查）")


def verify_example2():
    """
    算例2结果校核。
    检查项：
      1. LM 矩阵自动生成
      2. 节点3位移
      3. 单元应力
      4. 总体刚度矩阵对称性和奇异性
    """
    print("\n" + "="*60)
    print("  算例2 结果校核")
    print("="*60)

    # 预期位移（来自课程例题 2.2 和作业算例 2）
    u3_expected = 38.284271
    v3_expected = -10.000000

    print("\n检查1: LM 矩阵自动生成")
    LM_expected = np.array([[1, 3],    # 0-based: [0, 2] → [1, 3]
                            [2, 4],    #           [1, 3] → [2, 4]
                            [5, 5],    #           [4, 4] → [5, 5]
                            [6, 6]])   #           [5, 5] → [6, 6]]
    print(f"  实际 LM (1-based):\n{LM + 1}")
    print(f"  预期 LM:\n{LM_expected}")
    if np.array_equal(LM + 1, LM_expected):
        print("  LM 矩阵自动生成正确 ✓")

    print("\n检查2: 节点3位移")
    u3 = d[4, 0]    # 自由度5（0-based索引4）
    v3 = d[5, 0]    # 自由度6（0-based索引5）
    print(f"  u3 = {u3:.6f}，预期 = {u3_expected:.6f}")
    print(f"  v3 = {v3:.6f}，预期 = {v3_expected:.6f}")
    if abs(u3 - u3_expected) < 0.01 and abs(v3 - v3_expected) < 0.01:
        print("  节点3位移正确 ✓")

    print("\n检查3: 单元应力")
    sigma1_expected = -10.000000
    sigma2_expected = 14.142136
    print(f"  单元1 应力 = {stress[0]:.6f}，预期 = {sigma1_expected:.6f}")
    print(f"  单元2 应力 = {stress[1]:.6f}，预期 = {sigma2_expected:.6f}")
    if abs(stress[0] - sigma1_expected) < 0.01:
        print("  单元1应力正确 ✓")
    if abs(stress[1] - sigma2_expected) < 0.01:
        print("  单元2应力正确 ✓")


# ==============================================================================
# 程序入口
# ==============================================================================

if __name__ == "__main__":
    nargs = len(sys.argv)

    if nargs >= 2:
        # 指定输入文件运行
        json_file = sys.argv[1]
        run_analysis(json_file)
    else:
        # 无参数时，自动创建并运行两个验证算例
        print("="*60)
        print("  总体刚度矩阵组装与桁架结构求解程序")
        print("  用法: python truss_fem.py <input.json>")
        print("  未指定输入文件，将自动运行两个验证算例")
        print("="*60)

        # ---------- 算例 1：一维两单元杆结构 ----------
        print("\n\n" + "#"*70)
        print("#  算例 1：一维两单元杆结构")
        print("#"*70)
        f1 = create_example1_json()
        run_analysis(f1)
        verify_example1()

        # ---------- 算例 2：二维两杆桁架结构 ----------
        print("\n\n" + "#"*70)
        print("#  算例 2：二维两杆桁架结构")
        print("#"*70)
        f2 = create_example2_json()
        run_analysis(f2)
        verify_example2()

        # ---------- 总结 ----------
        print("\n\n" + "="*60)
        print("  全部算例运行完毕！")
        print("="*60)
        print("""
总体刚度矩阵性质分析：
  1. 对称性：K = K^T（由材料本构关系和功的互等定理保证）
  2. 奇异性：施加位移边界条件前 K 为奇异矩阵（存在刚体位移自由度）
  3. 稀疏性：K 为高度稀疏矩阵（仅相邻节点间有非零刚度贡献）
  4. 对角元非负性：K 的对角元素 K_{jj} >= 0
  5. 物理意义：K 的第 j 列表示当第 j 个自由度给定单位位移、
     其余自由度固定时，为保持平衡需在各自由度上施加的节点力
""")
