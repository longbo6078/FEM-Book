#!/usr/bin/env python3
"""
一维对流扩散方程的有限元求解与稳定化
FEM Solution and Stabilization for 1D Advection-Diffusion Equation
对应章节: 3.8 Advection-Diffusion Equation
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')  # 无显示器环境使用；如有图形界面可注释掉此行
import matplotlib.pyplot as plt


# =====================================================================
#  核心计算函数
# =====================================================================

def element_matrix(kappa, v, le, alpha):
    """
    计算两节点线性单元的 2x2 对流扩散单元矩阵。
    Ke = kappa_bar/le * [[1,-1],[-1,1]] + v/2 * [[-1,1],[-1,1]]
    其中 kappa_bar = kappa + alpha * v * le / 2
      alpha=0  : 标准 Galerkin FEM
      alpha=1  : 迎风格式
      alpha_opt: SUPG / Petrov-Galerkin
    """
    kappa_bar = kappa + alpha * v * le / 2.0
    Ke_diff = (kappa_bar / le) * np.array([[ 1.0, -1.0],
                                           [-1.0,  1.0]])
    Ke_conv = (v / 2.0)        * np.array([[-1.0,  1.0],
                                           [-1.0,  1.0]])
    return Ke_diff + Ke_conv


def alpha_supg(Pe):
    """SUPG / Petrov-Galerkin 最优参数: alpha_opt = coth(Pe) - 1/Pe"""
    if abs(Pe) < 1e-10:
        return 0.0
    return 1.0 / np.tanh(Pe) - 1.0 / Pe


def exact_solution(x, v, kappa, L):
    """
    精确解 theta(x) = (exp(v*x/kappa)-1) / (exp(v*L/kappa)-1)
    采用数值稳定形式避免指数溢出:
    theta(x) = (exp(v*(x-L)/kappa) - exp(-v*L/kappa)) / (1 - exp(-v*L/kappa))
    """
    ratio = v / kappa
    exp_neg_L = np.exp(-ratio * L)
    return (np.exp(ratio * (x - L)) - exp_neg_L) / (1.0 - exp_neg_L)


def assemble_global(nel, L, v, kappa, alpha):
    """组装总体矩阵 K 和载荷向量 f（不含边界条件处理）。"""
    le = L / nel
    nn = nel + 1
    Pe = v * le / (2.0 * kappa)

    x = np.linspace(0, L, nn)
    K = np.zeros((nn, nn))
    f = np.zeros(nn)

    for e in range(nel):
        Ke = element_matrix(kappa, v, le, alpha)
        dofs = [e, e + 1]
        for i in range(2):
            for j in range(2):
                K[dofs[i], dofs[j]] += Ke[i, j]

    return K, f, x, le, Pe


def solve_advection_diffusion(nel, L, v, kappa, alpha):
    """
    完整求解: 组装 → 施加 Dirichlet BC → 求解。
    返回: x, d, theta_exact, K_original(施加BC前), Pe
    """
    K, f, x, le, Pe = assemble_global(nel, L, v, kappa, alpha)
    K_original = K.copy()
    nn = nel + 1

    # ---- 施加 Dirichlet 边界条件: theta(0)=0, theta(L)=1 ----
    # 将已知值 theta(nn-1)=1 的贡献移到右端
    for i in range(nn):
        f[i] -= K[i, nn - 1] * 1.0

    # 节点 0: theta = 0
    K[0, :]    = 0.0;  K[:, 0]    = 0.0;  K[0, 0]       = 1.0;  f[0]       = 0.0
    # 节点 nn-1: theta = 1
    K[nn-1, :] = 0.0;  K[:, nn-1] = 0.0;  K[nn-1, nn-1] = 1.0;  f[nn-1]    = 1.0

    d = np.linalg.solve(K, f)
    theta_exact = exact_solution(x, v, kappa, L)
    return x, d, theta_exact, K_original, Pe


# =====================================================================
#  主程序
# =====================================================================

def main():
    # ---- 全局参数 ----
    L   = 1.0
    nel = 20
    v   = 1.0
    le  = L / nel

    Pe_cases = [0.1, 3.0]
    methods = [
        {"name": "Standard Galerkin",
         "alpha_func": lambda pe: 0.0,
         "color": "#2563eb", "marker": "o", "ls": "-"},
        {"name": "Upwind",
         "alpha_func": lambda pe: 1.0,
         "color": "#16a34a", "marker": "s", "ls": "--"},
        {"name": "SUPG/Petrov-Galerkin",
         "alpha_func": lambda pe: alpha_supg(pe),
         "color": "#dc2626", "marker": "^", "ls": "-."},
    ]

    with open("advection_diffusion_results.txt", "w", encoding="utf-8") as fout:

        # ==================== 报告头部 ====================
        fout.write("=" * 72 + "\n")
        fout.write("  一维对流扩散方程 有限元求解与稳定化 结果报告\n")
        fout.write("=" * 72 + "\n\n")
        fout.write("【基本参数】\n")
        fout.write(f"  控制方程:  -kappa * d²theta/dx² + v * dtheta/dx = 0\n")
        fout.write(f"  计算域:    [0, L],  L = {L}\n")
        fout.write(f"  边界条件:  theta(0) = 0,  theta(L) = 1\n")
        fout.write(f"  对流速度:  v = {v}\n")
        fout.write(f"  单元数:    nel = {nel}\n")
        fout.write(f"  单元长度:  le = L/nel = {le}\n")
        fout.write(f"  Peclet数:  Pe = v*le / (2*kappa)\n")
        fout.write(f"  精确解:    theta(x) = [exp(vx/kappa)-1] / [exp(vL/kappa)-1]\n\n")

        # ==========================================================
        #  任务 1: 组装总体方程
        # ==========================================================
        fout.write("=" * 72 + "\n")
        fout.write("任务 1: 组装总体方程\n")
        fout.write("=" * 72 + "\n\n")

        Pe_ex = 0.1
        kappa_ex = v * le / (2.0 * Pe_ex)
        fout.write(f"以 Pe = {Pe_ex} (kappa = {kappa_ex}) 的标准 Galerkin 为例:\n\n")

        # 单元矩阵
        Ke_ex = element_matrix(kappa_ex, v, le, alpha=0.0)
        fout.write("单元矩阵 Ke (标准 Galerkin):\n")
        for row in Ke_ex:
            fout.write("  [" + ", ".join(f"{val:12.6f}" for val in row) + "]\n")
        fout.write(f"\n单元 Peclet 数: Pe = v*le/(2*kappa) = {v}*{le}/(2*{kappa_ex}) = {Pe_ex}\n")

        # 总体矩阵概览
        K_ex, _, _, _, _ = assemble_global(nel, L, v, kappa_ex, 0.0)
        fout.write(f"\n总体矩阵维度: {K_ex.shape[0]} x {K_ex.shape[1]}\n")
        fout.write("总体矩阵 K (前 5x5 子块):\n")
        for i in range(5):
            fout.write("  [" + ", ".join(f"{K_ex[i,j]:8.4f}" for j in range(5)) + " ...]\n")
        fout.write("  ...\n\n")

        # 组装过程说明
        fout.write("组装过程:\n")
        fout.write(f"  1. 生成 nel = {nel} 个等长线性单元\n")
        fout.write(f"  2. 对每个单元 e，计算 Ke 并按连接关系组装到总体矩阵 K\n")
        fout.write(f"  3. 施加 Dirichlet 边界条件 theta(0)=0, theta(L)=1\n")
        fout.write(f"  4. 求解线性方程组 K*d = f\n\n")

        # 求解并输出节点值
        x_ex, d_ex, te_ex, _, _ = solve_advection_diffusion(nel, L, v, kappa_ex, 0.0)
        fout.write("求解结果 (节点坐标 / 数值解 / 精确解):\n")
        fout.write(f"  {'Node':>4s} {'x':>10s} {'Numerical':>16s} {'Exact':>16s}\n")
        fout.write("  " + "-" * 50 + "\n")
        for i in range(len(x_ex)):
            fout.write(f"  {i:4d} {x_ex[i]:10.4f} {d_ex[i]:16.8f} {te_ex[i]:16.8f}\n")
        fout.write("\n")

        # ==========================================================
        #  任务 2 & 3: 比较不同 Peclet 数 + 绘图与误差分析
        # ==========================================================
        error_table = {}

        for Pe_target in Pe_cases:
            kappa = v * le / (2.0 * Pe_target)

            fout.write("=" * 72 + "\n")
            fout.write(f"任务 2 & 3: Pe = {Pe_target}\n")
            fout.write(f"  kappa = v*le/(2*Pe) = {v}*{le}/(2*{Pe_target}) = {kappa:.8f}\n")
            fout.write("=" * 72 + "\n\n")

            error_table[Pe_target] = {}

            # ---- 绘图 ----
            fig, ax = plt.subplots(figsize=(10, 6))
            x_fine = np.linspace(0, L, 500)
            theta_fine = exact_solution(x_fine, v, kappa, L)
            ax.plot(x_fine, theta_fine, 'k-', linewidth=2.0, label='Exact Solution', zorder=1)

            fout.write(f"  {'Method':<30s} {'alpha':>12s} {'Max Error':>16s}\n")
            fout.write("  " + "-" * 62 + "\n")

            for method in methods:
                alpha = method["alpha_func"](Pe_target)
                x, d, te, _, _ = solve_advection_diffusion(nel, L, v, kappa, alpha)
                max_err = np.max(np.abs(d - te))
                error_table[Pe_target][method["name"]] = {
                    "alpha": alpha, "max_error": max_err
                }

                fout.write(f"  {method['name']:<30s} {alpha:>12.6f} {max_err:>16.6e}\n")

                ax.plot(x, d, color=method["color"], marker=method["marker"],
                        markersize=7, linewidth=1.8, linestyle=method["ls"],
                        label=f"{method['name']} (a={alpha:.4f})", zorder=2)

            ax.set_xlabel('x', fontsize=14)
            ax.set_ylabel(r'$\theta(x)$', fontsize=14)
            ax.set_title(f'1D Advection-Diffusion FEM  (Pe = {Pe_target}, nel = {nel})',
                         fontsize=14, fontweight='bold')
            ax.legend(fontsize=10, loc='best')
            ax.grid(True, alpha=0.3, linestyle='--')
            ax.set_xlim(0, L)
            plt.tight_layout()
            fname = f"result_Pe{Pe_target}.png"
            plt.savefig(fname, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"  已保存图片: {fname}")

            fout.write("\n")
            if Pe_target < 1:
                fout.write(f"  【分析】Pe = {Pe_target} < 1 (扩散占优):\n")
                fout.write(f"    - 各格式均能得到较平滑的结果\n")
                fout.write(f"    - 标准 Galerkin 解与精确解非常接近，不出现明显振荡\n")
                fout.write(f"    - 人工扩散影响可忽略\n\n")
            else:
                fout.write(f"  【分析】Pe = {Pe_target} > 1 (对流占优):\n")
                fout.write(f"    - 标准 Galerkin 解出现明显节点振荡\n")
                fout.write(f"    - 迎风格式消除振荡，但引入较强数值扩散（边界层被明显抹平）\n")
                a_opt = alpha_supg(Pe_target)
                fout.write(f"    - SUPG/Petrov-Galerkin (alpha_opt = coth(Pe)-1/Pe = {a_opt:.6f})\n")
                fout.write(f"      在稳定性和精度之间取得更好平衡，节点值是精确的\n\n")

        # ---- 误差汇总表 ----
        fout.write("=" * 72 + "\n")
        fout.write("误差汇总表\n")
        fout.write("=" * 72 + "\n\n")
        fout.write(f"  {'Pe':<8s} {'Method':<30s} {'alpha':>12s} {'Max Error':>16s}\n")
        fout.write("  " + "-" * 70 + "\n")
        for Pe_t in Pe_cases:
            for m in methods:
                info = error_table[Pe_t][m["name"]]
                fout.write(f"  {Pe_t:<8.1f} {m['name']:<30s} "
                           f"{info['alpha']:>12.6f} {info['max_error']:>16.6e}\n")
            fout.write("  " + "-" * 70 + "\n")
        fout.write("\n")

        # ==========================================================
        #  任务 4: 矩阵性质分析 (Pe = 3.0)
        # ==========================================================
        Pe3 = 3.0
        k3 = v * le / (2.0 * Pe3)

        fout.write("=" * 72 + "\n")
        fout.write(f"任务 4: 矩阵性质分析 (Pe = {Pe3})\n")
        fout.write(f"  扩散系数 kappa = {k3:.8f}\n")
        fout.write("=" * 72 + "\n\n")

        K_g, _, _, _, _ = assemble_global(nel, L, v, k3, 0.0)
        nn = nel + 1

        # 输出总体矩阵
        fout.write("1. 标准 Galerkin 总体矩阵 K (施加边界条件前):\n\n")
        for i in range(nn):
            fout.write("   " + "  ".join(f"{K_g[i,j]:8.4f}" for j in range(nn)) + "\n")

        # (1) 对称性
        is_sym = np.allclose(K_g, K_g.T, atol=1e-12)
        fout.write(f"\n2. 对称性检查:\n")
        fout.write(f"   矩阵是否对称: {'是' if is_sym else '否'}\n")
        if not is_sym:
            asym_norm = np.max(np.abs(K_g - K_g.T))
            fout.write(f"   ||K - K^T||_max = {asym_norm:.6e}\n")
            fout.write(f"   原因: 对流矩阵 K_A 是非对称矩阵（参见课件 3.8）\n")

        # (2) 正定性
        eigs = np.real(np.linalg.eigvals(K_g))
        min_eig = np.min(eigs)
        max_eig = np.max(eigs)
        fout.write(f"\n3. 正定性检查:\n")
        fout.write(f"   矩阵是否正定: {'是' if min_eig > 0 else '否'}\n")
        fout.write(f"   最小特征值: {min_eig:.6e}\n")
        fout.write(f"   最大特征值: {max_eig:.6e}\n")
        if min_eig <= 0:
            neg_count = int(np.sum(eigs < 0))
            fout.write(f"   负特征值个数: {neg_count}\n")
            fout.write(f"   验证 (取 z^T=[1,0]):  z^T K^e z = (kappa/l)(1-Pe) = "
                       f"{k3/le*(1-Pe3):.6f} < 0\n")

        # (3) 对流项影响
        fout.write(f"\n4. 对流项对矩阵性质的影响:\n")
        fout.write(f"   - 扩散矩阵 K_D 对称正定\n")
        fout.write(f"   - 对流矩阵 K_A 非对称\n")
        fout.write(f"   - 总体矩阵 K = K_D + K_A 不再保证对称性和正定性\n")
        fout.write(f"   - 对称性和正定性的丧失使得方程求解极其困难\n")

        # (4) 振荡原因
        fout.write(f"\n5. 对流占优时标准 Galerkin 解出现空间振荡的原因:\n")
        fout.write(f"   (a) 数学角度: 弱形式不适定（双线性形式不满足椭圆性条件）\n")
        fout.write(f"   (b) 差分角度: 对流项采用中心差分近似，未考虑上下游差异\n")
        fout.write(f"   (c) 弱形式角度: Galerkin 权函数对称，未考虑上下游差异\n")
        lam2 = (1 + Pe3) / (1 - Pe3)
        fout.write(f"   (d) 特征方程 (1-Pe)*lam^2 - 2*lam + (1+Pe) = 0:\n")
        fout.write(f"       lam_1 = 1,  lam_2 = (1+Pe)/(1-Pe) = {lam2:.4f}\n")
        fout.write(f"       当 Pe = {Pe3} > 1 时 lam_2 < 0  =>  解振荡\n\n")

        # ==========================================================
        #  附加题: 网格收敛性分析
        # ==========================================================
        fout.write("=" * 72 + "\n")
        fout.write("附加题: 网格加密对 Galerkin 振荡和 SUPG 误差的影响\n")
        fout.write("=" * 72 + "\n\n")

        nel_list = [10, 20, 40, 80]

        for Pe_t in [0.1, 3.0]:
            fout.write(f"Pe = {Pe_t}:\n")
            fout.write(f"  {'nel':<6s} {'le':>10s} {'Galerkin':>16s} "
                       f"{'Upwind':>16s} {'SUPG':>16s}\n")
            fout.write("  " + "-" * 68 + "\n")

            les_l, eg_l, eu_l, es_l = [], [], [], []

            for nv in nel_list:
                lv = L / nv
                kv = v * lv / (2.0 * Pe_t)
                les_l.append(lv)

                _, dg, teg, _, _ = solve_advection_diffusion(nv, L, v, kv, 0.0)
                _, du, teu, _, _ = solve_advection_diffusion(nv, L, v, kv, 1.0)
                ao = alpha_supg(Pe_t)
                _, ds, tes, _, _ = solve_advection_diffusion(nv, L, v, kv, ao)

                eg_l.append(np.max(np.abs(dg - teg)))
                eu_l.append(np.max(np.abs(du - teu)))
                es_l.append(np.max(np.abs(ds - tes)))

                fout.write(f"  {nv:<6d} {lv:>10.6f} {eg_l[-1]:>16.6e} "
                           f"{eu_l[-1]:>16.6e} {es_l[-1]:>16.6e}\n")

            # 收敛曲线图
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.loglog(les_l, eg_l, 'bo-',  ms=8, lw=2, label='Standard Galerkin')
            ax.loglog(les_l, eu_l, 'gs-',  ms=8, lw=2, label='Upwind')
            ax.loglog(les_l, es_l, 'r^-',  ms=8, lw=2, label='SUPG/Petrov-Galerkin')
            ax.set_xlabel(r'Element size $l_e$', fontsize=14)
            ax.set_ylabel('Maximum node error', fontsize=14)
            ax.set_title(f'Error Convergence  (Pe = {Pe_t}, v = {v}, L = {L})',
                         fontsize=14, fontweight='bold')
            ax.legend(fontsize=11)
            ax.grid(True, alpha=0.3, linestyle='--', which='both')
            ax.invert_xaxis()
            plt.tight_layout()
            conv_f = f"convergence_Pe{Pe_t}.png"
            plt.savefig(conv_f, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"  已保存图片: {conv_f}")

            fout.write("\n")
            if Pe_t > 1:
                fout.write(f"  分析 (Pe = {Pe_t} > 1, 对流占优):\n")
                fout.write(f"    - 网格加密 (le 减小) 时，单元 Peclet 数 Pe = v*le/(2*kappa) 减小\n")
                fout.write(f"    - 当 Pe < 1 后 Galerkin 方法不再振荡\n")
                fout.write(f"    - 人工扩散项 alpha*v*le/2 随 le 减小，数值解逐渐接近精确解\n")
                fout.write(f"    - SUPG 方法在所有网格上均保持较好精度\n\n")
            else:
                fout.write(f"  分析 (Pe = {Pe_t} < 1, 扩散占优):\n")
                fout.write(f"    - 各方法在所有网格上均表现良好\n")
                fout.write(f"    - 网格加密时精度持续提高\n\n")

        fout.write("=" * 72 + "\n")
        fout.write("程序运行完毕\n")
        fout.write("=" * 72 + "\n")

    print("\n结果已保存到: advection_diffusion_results.txt")
    print("所有图片已生成完毕。")


if __name__ == "__main__":
    main()
