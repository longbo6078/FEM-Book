"""
===================================================================
程序设计作业：三维杆单元刚度矩阵与应力计算
学号：202311012147      姓名：龙波
===================================================================
  统一单位制:
    力       ——  N   (牛顿)
    长度     ——  m   (米)
    应力     ——  Pa  (帕斯卡)
    弹性模量 ——  Pa
    截面积   ——  m²
    位移     ——  m
===================================================================
  核心计算全部基于课件公式手写实现，
  未调用任何有限元商业软件或现成有限元库。
  基础矩阵运算使用 NumPy。
===================================================================
"""

import numpy as np
import sys


# =====================================================================
#               输出分流：同时写入控制台和 txt 文件
# =====================================================================
class Tee:
    """将 print 输出同时显示在控制台并写入文件"""
    def __init__(self, file):
        self.file = file
        self.stdout = sys.stdout          # 保存原始控制台引用

    def write(self, data):
        self.stdout.write(data)           # 写到控制台
        self.file.write(data)             # 写到文件

    def flush(self):
        self.stdout.flush()
        self.file.flush()


# =====================================================================
#                         核心计算函数
# =====================================================================

def truss3dElement_stiffness(x1, x2, E, A):
    """
    计算三维杆单元在全局坐标系下的 6×6 单元刚度矩阵。

    公式原理 (课件 2.2):
        方向余弦:  cx = (x2-x1)/L,  cy = (y2-y1)/L,  cz = (z2-z1)/L
        刚度系数:  k = E·A / L
        变换矩阵:  T (2×6) 将全局位移映射为局部轴向位移 d' = T·d
        局部刚度:  K'e = k·[[1, -1], [-1, 1]]
        全局刚度:  Ke = Tᵀ · K'e · T

    参数
    ----
    x1 : array-like  节点1坐标 [x, y, z]  单位: m
    x2 : array-like  节点2坐标 [x, y, z]  单位: m
    E  : float       弹性模量             单位: Pa
    A  : float       截面积               单位: m²

    返回
    ----
    L    : float      单元长度 (m)
    cos  : tuple      方向余弦 (cx, cy, cz)
    Ke   : ndarray    6×6 全局坐标系单元刚度矩阵 (N/m)
    """
    x1 = np.asarray(x1, dtype=float)
    x2 = np.asarray(x2, dtype=float)

    # ---- 计算单元长度和方向余弦 ----
    # Δx = x2 - x1 = [x21, y21, z21]
    delta = x2 - x1
    L = np.linalg.norm(delta)                # 单元长度 (m)

    # 退化单元检查：两个节点重合时无法构成有效杆单元
    if L < 1e-15:
        raise ValueError("错误：两个节点重合 (L ≈ 0)，无法构成有效杆单元。")

    # 方向余弦: cx, cy, cz (无量纲)
    cx, cy, cz = delta / L

    # ---- 构建刚度矩阵 ----
    k = E * A / L                            # 单元刚度系数 k = EA/L  (N/m)

    # T: 2×6 坐标变换矩阵
    #    [u'1x]   [cx cy cz  0  0  0 ]   [u1x]
    #    [    ] = [                    ] · [u1y]
    #    [u'2x]   [ 0  0  0 cx cy cz ]   [u1z]
    #                                      [u2x]
    #                                      [u2y]
    #                                      [u2z]
    T = np.array([[cx, cy, cz,  0,  0,  0],
                  [ 0,  0,  0, cx, cy, cz]])

    # K'e: 局部坐标系下 2×2 刚度矩阵 (N/m)
    K_local = k * np.array([[ 1.0, -1.0],
                            [-1.0,  1.0]])

    # Ke: 全局坐标系下 6×6 刚度矩阵 (N/m)
    #     Ke = Tᵀ · K'e · T
    Ke = T.T @ K_local @ T

    return L, (cx, cy, cz), Ke


def truss3dElement_stress(x1, x2, E, A, de):
    """
    根据节点位移计算三维杆单元的轴向应变、应力和轴力。

    公式原理 (课件 2.2):
        B 矩阵:  B = (1/L)·[-cx -cy -cz  cx  cy  cz]  (1×6)
        应变:    ε = B · de
        应力:    σ = E · ε        (胡克定律)
        轴力:    N = A · σ        (受拉为正)

    参数
    ----
    x1 : array-like  节点1坐标 [x, y, z]   单位: m
    x2 : array-like  节点2坐标 [x, y, z]   单位: m
    E  : float       弹性模量              单位: Pa
    A  : float       截面积                单位: m²
    de : array-like  节点位移 [u1,v1,w1, u2,v2,w2]  单位: m

    返回
    ----
    epsilon : float  轴向应变 (无量纲)
    sigma   : float  轴向应力 (Pa)
    N       : float  轴力 (N)，受拉为正
    """
    x1 = np.asarray(x1, dtype=float)
    x2 = np.asarray(x2, dtype=float)
    de = np.asarray(de, dtype=float)

    # 计算方向余弦
    delta = x2 - x1
    L = np.linalg.norm(delta)

    if L < 1e-15:
        raise ValueError("错误：两个节点重合 (L ≈ 0)，无法构成有效杆单元。")

    cx, cy, cz = delta / L

    # B: 1×6 应变-位移矩阵
    #    ε = B · de = (1/L)·[-cx -cy -cz  cx  cy  cz] · [u1 v1 w1 u2 v2 w2]ᵀ
    B = np.array([-cx, -cy, -cz, cx, cy, cz]) / L

    # 轴向应变 (无量纲)
    epsilon = float(B @ de)

    # 轴向应力 (Pa)  ——  胡克定律: σ = E · ε
    sigma = E * epsilon

    # 轴力 (N)  ——  N = A · σ，受拉为正
    N = A * sigma

    return epsilon, sigma, N


# =====================================================================
#                       辅助验证函数
# =====================================================================

def check_symmetry(Ke):
    """检查刚度矩阵是否对称: Ke ≈ Keᵀ"""
    return np.allclose(Ke, Ke.T, atol=1e-8)


def check_singular(Ke):
    """检查刚度矩阵是否奇异: det(Ke) ≈ 0"""
    det_val = np.linalg.det(Ke)
    return det_val, np.isclose(det_val, 0, atol=1e-4)


def check_eigenvalues(Ke):
    """计算特征值并检查半正定性（所有特征值应 ≥ 0）"""
    eigenvalues = np.linalg.eigvalsh(Ke)
    all_nonneg = np.all(eigenvalues >= -1e-8)
    return eigenvalues, all_nonneg


def check_rigid_body_translation(Ke):
    """
    检查刚体平移是否不产生内力。
    令所有自由度位移 = 1 m，计算 Fe = Ke · d (N)，应 ≈ 0。
    """
    d_rigid = np.ones(6)       # 刚体平移位移向量 (m)
    F_rigid = Ke @ d_rigid     # 节点力 (N)
    is_zero = np.allclose(F_rigid, 0, atol=1e-8)
    return F_rigid, is_zero


def verify_column_meaning(Ke):
    """
    任务4: 单元刚度矩阵物理意义验证。

    方法: 令第 j 个自由度位移 = 1 (m)，其余 = 0，
          计算 Fe = Ke · de，验证 Fe 是否等于 Ke 的第 j 列。

    物理意义:
        K_ij 表示当单元第 j 个自由度给定单位位移而其它自由度固定时，
        为使单元平衡而在第 i 个自由度上所需施加的节点力 (N)。
    """
    dof_labels = ['u1', 'v1', 'w1', 'u2', 'v2', 'w2']

    print("\n" + "=" * 70)
    print("  任务4：单元刚度矩阵物理意义验证")
    print("=" * 70)
    print("  方法: 令第 j 个自由度位移 = 1 m，其余 = 0")
    print("        计算 Fe = Ke · de，验证 Fe = Ke 的第 j 列")
    print("  物理意义: K_ij = 第 j 个自由度发生单位位移时，")
    print("            第 i 个自由度上需施加的节点力 (N)")
    print("-" * 70)

    all_match = True
    for j in range(6):
        # 构造位移向量: 第 j 个自由度 = 1 m，其余 = 0
        de = np.zeros(6)
        de[j] = 1.0

        # 计算节点力 (N)
        Fe     = Ke @ de
        # 取 Ke 第 j 列 (N/m × m = N)
        Ke_col = Ke[:, j]

        match = np.allclose(Fe, Ke_col, atol=1e-10)
        all_match = all_match and match

        print(f"\n  j = {j}  ({dof_labels[j]})")
        print(f"    de       = {np.array2string(de, precision=1, floatmode='fixed')}")
        print(f"    Fe (N)   = {np.array2string(Fe, precision=4, floatmode='fixed', suppress_small=True)}")
        print(f"    Ke[:,{j}]  = {np.array2string(Ke_col, precision=4, floatmode='fixed', suppress_small=True)}")
        print(f"    一致: {'是' if match else '否'}")

    print("\n" + "-" * 70)
    result = "全部通过" if all_match else "存在不一致"
    print(f"  验证结论: {result}")


# =====================================================================
#                   整体刚度矩阵组装 (附加题)
# =====================================================================

def assemble_global_stiffness(elements, num_nodes):
    """
    将多个杆单元刚度矩阵组装为整体刚度矩阵。

    原理: 对每个单元，将其 6×6 单元刚度矩阵按全局自由度编号
          叠加到整体刚度矩阵的对应位置。

    参数
    ----
    elements  : list[dict]  单元信息列表，每个元素包含:
                  'n1'    : 节点1编号 (int)
                  'n2'    : 节点2编号 (int)
                  'E'     : 弹性模量 (Pa)
                  'A'     : 截面积 (m²)
                  'coords': np.array([[x1,y1,z1],[x2,y2,z2]]) (m)
    num_nodes : int          节点总数

    返回
    ----
    KG : ndarray  整体刚度矩阵 (num_nodes*3 × num_nodes*3)，单位 N/m
    """
    total_dof = num_nodes * 3
    KG = np.zeros((total_dof, total_dof))

    for elem in elements:
        n1, n2 = elem['n1'], elem['n2']
        x1 = elem['coords'][0]          # m
        x2 = elem['coords'][1]          # m
        E  = elem['E']                  # Pa
        A  = elem['A']                  # m²

        # 计算该单元的 6×6 刚度矩阵 (N/m)
        _, _, Ke = truss3dElement_stiffness(x1, x2, E, A)

        # 每个节点 3 个平动自由度 (u, v, w)
        dofs = [n1*3, n1*3+1, n1*3+2, n2*3, n2*3+1, n2*3+2]

        # 叠加到整体刚度矩阵
        for i in range(6):
            for j in range(6):
                KG[dofs[i], dofs[j]] += Ke[i, j]

    return KG


def solve_space_truss_example():
    """
    附加题: 求解简单空间桁架结构的节点位移和杆件应力。

    结构 (正四面体桁架，底面三节点固定):
        节点0: (0,     0,     0     ) m  — 固定铰支座
        节点1: (1,     0,     0     ) m  — 固定铰支座
        节点2: (0.5,   0.8660, 0     ) m  — 固定铰支座
        节点3: (0.5,   0.2887, 0.8165) m  — 自由节点

    杆件: 0-3, 1-3, 2-3 (正四面体 3 条侧棱)
    载荷: 节点3 施加 Fz = -5000 N

    单位: N, m, Pa
    """
    # ---- 节点坐标 (m) ----
    nodes = np.array([
        [0.0,    0.0,    0.0    ],   # 节点0 (固定)
        [1.0,    0.0,    0.0    ],   # 节点1 (固定)
        [0.5,    0.8660, 0.0    ],   # 节点2 (固定)
        [0.5,    0.2887, 0.8165],   # 节点3 (自由)
    ])

    E = 210e9       # 弹性模量 (Pa)
    A = 1.0e-4      # 截面积 (m²)

    # ---- 杆件连接: 仅 3 根杆连接到自由节点 ----
    connections = [(0, 3), (1, 3), (2, 3)]

    elements = []
    for n1, n2 in connections:
        elements.append({
            'n1': n1, 'n2': n2,
            'E': E, 'A': A,
            'coords': np.array([nodes[n1], nodes[n2]])
        })

    num_nodes = len(nodes)
    total_dof = num_nodes * 3

    # ---- 1. 组装整体刚度矩阵 (N/m) ----
    KG = assemble_global_stiffness(elements, num_nodes)

    print(f"\n  整体刚度矩阵 KG ({total_dof}×{total_dof})，单位 N/m:")
    print(format_matrix(KG, label="KG"))

    # ---- 2. 载荷向量 (N) ----
    F = np.zeros(total_dof)             # N
    F[3 * 3 + 2] = -5000.0             # 节点3, z方向, -5000 N

    print(f"\n  载荷向量 F (N):")
    for i in range(num_nodes):
        print(f"    节点{i}: Fx={F[i*3]:+.1f}, Fy={F[i*3+1]:+.1f}, Fz={F[i*3+2]:+.1f}")

    # ---- 3. 边界条件: 节点 0, 1, 2 固定 (自由度 0~8) ----
    fixed_dofs = list(range(9))
    free_dofs  = [i for i in range(total_dof) if i not in fixed_dofs]

    print(f"\n  固定自由度 (9个): 节点0,1,2 的 u,v,w")
    print(f"  自由自由度 (3个): 节点3 的 u,v,w")

    # ---- 4. 提取子矩阵并求解 ----
    K_ff = KG[np.ix_(free_dofs, free_dofs)]     # N/m
    F_f  = F[free_dofs]                          # N

    print(f"\n  自由度子矩阵 K_ff (N/m):")
    print(format_matrix(K_ff, label="K_ff"))

    # 奇异性检查
    det_Kff = np.linalg.det(K_ff)
    print(f"\n  det(K_ff) = {det_Kff:.6e}  (N/m)³")

    if np.isclose(det_Kff, 0, atol=1e-6):
        print("  警告: K_ff 奇异，结构可能存在机构！")
        return

    # 求解节点位移 (m):  K_ff · d_f = F_f
    d_f = np.linalg.solve(K_ff, F_f)

    # 组装完整位移向量 (m)
    d_full = np.zeros(total_dof)
    for i, dof in enumerate(free_dofs):
        d_full[dof] = d_f[i]

    print(f"\n  节点位移计算结果 (m):")
    print(f"  {'节点':<6}{'ux':>16}{'uy':>16}{'uz':>16}")
    print(f"  {'-' * 54}")
    for i in range(num_nodes):
        print(f"  {i:<6}{d_full[i*3]:>+16.6e}{d_full[i*3+1]:>+16.6e}{d_full[i*3+2]:>+16.6e}")

    # ---- 5. 计算各杆件应变、应力、轴力 ----
    print(f"\n  杆件内力计算结果 (单位: 应变无量纲, 应力 MPa, 轴力 N):")
    print(f"  {'杆件':<5}{'节点':<7}{'长度(m)':<10}{'应变':>14}{'应力(MPa)':>14}{'轴力(N)':>14}  {'状态'}")
    print(f"  {'-' * 76}")

    for idx, elem in enumerate(elements):
        n1, n2 = elem['n1'], elem['n2']

        # 提取该单元两端节点位移 (m)
        de_elem = np.array([
            d_full[n1*3], d_full[n1*3+1], d_full[n1*3+2],
            d_full[n2*3], d_full[n2*3+1], d_full[n2*3+2]
        ])

        # 计算应变、应力(Pa)、轴力(N)
        eps, sig, Nf = truss3dElement_stress(nodes[n1], nodes[n2], E, A, de_elem)
        L = np.linalg.norm(nodes[n2] - nodes[n1])
        status = "受拉" if Nf > 0 else ("受压" if Nf < 0 else "零力")

        print(f"  {idx+1:<5}{n1}-{n2:<4}{L:<10.4f}{eps:>+14.6e}{sig/1e6:>+14.4f}{Nf:>+14.4f}  {status}")


# =====================================================================
#                       输出格式化辅助
# =====================================================================

def format_matrix(M, label="", width=14, decimals=2):
    """
    格式化矩阵输出，所有元素保留相同小数位，列对齐。

    参数
    ----
    M        : ndarray  待输出矩阵
    label    : str      矩阵名称
    width    : int      每列总宽度
    decimals : int      小数位数
    """
    rows, cols = M.shape
    lines = []
    if label:
        lines.append(f"    {label} =")
    for i in range(rows):
        row_str = "    ["
        for j in range(cols):
            val = M[i, j]
            row_str += f"{val:>{width}.{decimals}f}"
            if j < cols - 1:
                row_str += ", "
        row_str += " ]"
        lines.append(row_str)
    return "\n".join(lines)


def print_section(title):
    """打印分节标题"""
    print("\n" + "#" * 70)
    print(f"# {title}")
    print("#" * 70)


# =====================================================================
#                             主程序
# =====================================================================

def main():
    print("=" * 70)
    print("     三维杆单元 / 空间桁架单元  刚度矩阵计算程序")
    print("     统一单位:  N (力),  m (长度),  Pa (应力/模量)")
    print("=" * 70)

    # =================================================================
    #  算例 1: 沿 x 轴的一维杆单元
    # =================================================================
    print_section("算例1：沿 x 轴的一维杆单元")

    # 输入参数
    x1_c1 = [0, 0, 0]                              # m
    x2_c1 = [2, 0, 0]                              # m
    E1    = 200e9                                    # Pa (200 GPa)
    A1    = 1.0e-4                                   # m²
    de1   = np.array([0, 0, 0, 1.0e-3, 0, 0])      # m

    # 计算刚度矩阵
    L1, (cx1, cy1, cz1), Ke1 = truss3dElement_stiffness(x1_c1, x2_c1, E1, A1)

    print(f"\n  输入参数 (单位: m, Pa, m²):")
    print(f"    节点1 = {x1_c1},  节点2 = {x2_c1}")
    print(f"    E     = {E1:.3e} Pa  (200 GPa)")
    print(f"    A     = {A1:.3e} m²")

    print(f"\n  计算结果:")
    print(f"    单元长度 L          = {L1:.4f} m")
    print(f"    方向余弦 (cx,cy,cz) = ({cx1:.4f}, {cy1:.4f}, {cz1:.4f})")

    print(f"\n  单元刚度矩阵 Ke (N/m):")
    print(format_matrix(Ke1, label="Ke"))

    # 计算应变、应力(Pa)、轴力(N)
    eps1, sig1, N1 = truss3dElement_stress(x1_c1, x2_c1, E1, A1, de1)

    print(f"\n  节点位移 de (m):")
    print(f"    de = {np.array2string(de1, precision=4, floatmode='fixed')}")
    print(f"\n  内力计算结果:")
    print(f"    轴向应变 ε  = {eps1:.6e}  (无量纲)")
    print(f"    轴向应力 σ  = {sig1:.6e} Pa  =  {sig1/1e6:.2f} MPa")
    print(f"    轴力    N   = {N1:.6e} N")

    # 验证结果
    print(f"\n  ── 与理论值对比验证 ──")
    checks_c1 = [
        ("单元长度 = 2 m",                np.isclose(L1, 2.0)),
        ("方向余弦 = (1, 0, 0)",           np.allclose((cx1, cy1, cz1), (1, 0, 0))),
        ("Ke 退化为一维杆形式",             np.isclose(Ke1[0, 0], Ke1[3, 3]) and np.isclose(Ke1[0, 0], -Ke1[0, 3])),
        ("轴向应变 = 5.0e-4",              np.isclose(eps1, 5.0e-4)),
        ("轴向应力 = 100 MPa",             np.isclose(sig1 / 1e6, 100.0)),
        ("轴力 = 1.0e4 N (10 kN)",         np.isclose(N1, 1.0e4)),
    ]
    for desc, ok in checks_c1:
        print(f"    {'✓' if ok else '✗'}  {desc}")

    # 刚度矩阵性质
    print(f"\n  ── 刚度矩阵性质验证 ──")
    print(f"    {'✓' if check_symmetry(Ke1) else '✗'}  对称性: Ke = Keᵀ")

    det1, is_sing1 = check_singular(Ke1)
    print(f"    {'✓' if is_sing1 else '✗'}  奇异性: det(Ke) = {det1:.6e} ≈ 0")

    eig1, nonneg1 = check_eigenvalues(Ke1)
    print(f"    {'✓' if nonneg1 else '✗'}  半正定性: 特征值 = [{', '.join(f'{v:.2e}' for v in eig1)}]")

    F_r1, is_z1 = check_rigid_body_translation(Ke1)
    print(f"    {'✓' if is_z1 else '✗'}  刚体平移不产生内力: Fe = {np.array2string(F_r1, precision=2, floatmode='fixed')}")

    # =================================================================
    #  算例 2: 空间任意方向杆单元
    # =================================================================
    print_section("算例2：空间任意方向杆单元")

    x1_c2 = [0, 0, 0]                                              # m
    x2_c2 = [1, 2, 2]                                              # m
    E2    = 210e9                                                    # Pa (210 GPa)
    A2    = 2.0e-4                                                   # m²
    de2   = np.array([0, 0, 0, 1.0e-3, 2.0e-3, 2.0e-3])           # m

    L2, (cx2, cy2, cz2), Ke2 = truss3dElement_stiffness(x1_c2, x2_c2, E2, A2)

    print(f"\n  输入参数 (单位: m, Pa, m²):")
    print(f"    节点1 = {x1_c2},  节点2 = {x2_c2}")
    print(f"    E     = {E2:.3e} Pa  (210 GPa)")
    print(f"    A     = {A2:.3e} m²")

    print(f"\n  计算结果:")
    print(f"    单元长度 L            = {L2:.4f} m")
    print(f"    方向余弦 (cx,cy,cz)    = ({cx2:.6f}, {cy2:.6f}, {cz2:.6f})")
    print(f"    理论值   (1/3,2/3,2/3) = ({1/3:.6f}, {2/3:.6f}, {2/3:.6f})")

    print(f"\n  单元刚度矩阵 Ke (N/m):")
    print(format_matrix(Ke2, label="Ke", width=16, decimals=2))

    eps2, sig2, N2 = truss3dElement_stress(x1_c2, x2_c2, E2, A2, de2)

    print(f"\n  节点位移 de (m):")
    print(f"    de = {np.array2string(de2, precision=4, floatmode='fixed')}")
    print(f"\n  内力计算结果:")
    print(f"    轴向应变 ε  = {eps2:.6e}  (无量纲)")
    print(f"    轴向应力 σ  = {sig2:.6e} Pa  =  {sig2/1e6:.2f} MPa")
    print(f"    轴力    N   = {N2:.6e} N")

    # 验证
    print(f"\n  ── 与理论值对比验证 ──")
    checks_c2 = [
        ("单元长度 = 3 m",                    np.isclose(L2, 3.0)),
        ("方向余弦 = (1/3, 2/3, 2/3)",         np.allclose((cx2, cy2, cz2), (1/3, 2/3, 2/3))),
        ("Ke 对称",                            check_symmetry(Ke2)),
        ("轴向应变 = 1.0e-3",                  np.isclose(eps2, 1.0e-3)),
        ("轴向应力 = 210 MPa",                 np.isclose(sig2 / 1e6, 210.0)),
        ("轴力 = 4.2e4 N (42 kN)",             np.isclose(N2, 4.2e4)),
    ]
    for desc, ok in checks_c2:
        print(f"    {'✓' if ok else '✗'}  {desc}")

    # 刚度矩阵性质
    print(f"\n  ── 刚度矩阵性质验证 ──")
    print(f"    {'✓' if check_symmetry(Ke2) else '✗'}  对称性: Ke = Keᵀ")

    det2, is_sing2 = check_singular(Ke2)
    print(f"    {'✓' if is_sing2 else '✗'}  奇异性: det(Ke) = {det2:.6e} ≈ 0")

    eig2, nonneg2 = check_eigenvalues(Ke2)
    print(f"    {'✓' if nonneg2 else '✗'}  半正定性: 特征值 = [{', '.join(f'{v:.2e}' for v in eig2)}]")

    F_r2, is_z2 = check_rigid_body_translation(Ke2)
    print(f"    {'✓' if is_z2 else '✗'}  刚体平移不产生内力: Fe = {np.array2string(F_r2, precision=2, floatmode='fixed')}")

    print(f"\n  说明:")
    print(f"    自由杆单元在空间中有 6 个刚体模态 (3 平动 + 3 转动)，")
    print(f"    本单元仅 6 个自由度且仅含 1 根杆，Ke 必然奇异 (|Ke| = 0)。")
    print(f"    零特征值对应刚体位移模态，刚体运动不产生内力。")

    # =================================================================
    #  任务 4: 刚度矩阵物理意义验证
    # =================================================================
    verify_column_meaning(Ke2)

    # =================================================================
    #  退化单元检查
    # =================================================================
    print_section("退化单元检查：两个节点重合")
    try:
        truss3dElement_stiffness([0, 0, 0], [0, 0, 0], 200e9, 1e-4)
    except ValueError as e:
        print(f"\n  捕获到预期错误:")
        print(f"    \"{e}\"")
        print(f"  程序正确拒绝了退化单元，未继续计算。")

    # =================================================================
    #  附加题: 空间桁架结构求解
    # =================================================================
    print_section("附加题：简单空间桁架结构求解")
    solve_space_truss_example()

    print("\n" + "=" * 70)
    print("  程序运行完毕。")
    print("=" * 70)


# =====================================================================
#  程序入口: 所有 print 输出同时显示在控制台并保存到 output.txt
# =====================================================================
if __name__ == "__main__":
    with open("output.txt", "w", encoding="utf-8") as f:
        sys.stdout = Tee(f)              # 重定向: 控制台 + 文件
        try:
            main()
        finally:
            sys.stdout = sys.__stdout__  # 恢复原始控制台

    print("\n运行结果已保存至 output.txt")
