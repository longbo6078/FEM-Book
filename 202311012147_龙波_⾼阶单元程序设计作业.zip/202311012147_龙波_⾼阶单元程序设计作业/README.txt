# 龙波 202311012147
# 高阶等参单元、完备性检验与数值积分 — 运行说明

**环境要求：** Python 3.8+，NumPy，SciPy，Matplotlib。

**运行方式：** 终端执行 `python 4.5.py`，结果输出至以下文件：
- `output/results.txt`（任务 1-6 完整计算结果）
- `output/test1.txt`（算例 1：形函数节点值检验）
- `output/test2.txt`（算例 2：单位分解检验）
- `output/test3.txt`（算例 3：Jacobian 检验）
- `output/test4.txt`（算例 4：二次场重构误差）
- `output/test5.txt`（算例 5：Poisson 方程误差收敛）

**算例说明：** 程序依次完成以下计算——
任务 1：实现 Q4、Q8、Q9 形函数并验证 Kronecker delta 和单位分解性质；
任务 2：对规则、非规则、曲边三种四边形检验等参映射的 Jacobian 合法性；
任务 3：实现 1x1 至 4x4 Gauss-Legendre 积分，比较完全积分与减缩积分规则；
任务 4：通过 patch test 检验三种单元对线性函数和二次函数的重构能力；
任务 5：求解二维 Poisson 方程，在 4x4、8x8、16x16 网格上比较 Q4/Q8/Q9 的精度、条件数和收敛性；
任务 6：实现 Q9 内部节点的静力凝聚，验证凝聚前后解的一致性。

**文件说明：**
- `4.5.py`：主程序源代码
- `README.txt`：运行说明
- `output/results.txt`：任务 1-6 完整计算结果
- `output/test1.txt` ~ `output/test5.txt`：五个验证算例的详细输入输出
- `output/Q4_nx4.png` ~ `output/Q9_nx16.png`：三种单元三种网格的数值解与误差图（共 9 张）
- `output/convergence.png`：Q4/Q8/Q9 误差收敛曲线图